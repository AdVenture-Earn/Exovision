import cv2
import pygame
import sys
import numpy as np

# === Configuration ===
VIDEO_PATH = "walkthrough.mp4"
FRAME_WIDTH = 1920
FRAME_HEIGHT = 1080

CROP_WIDTH = 720
CROP_HEIGHT = 720

MAX_HEAD_SHIFT_X = 600   # Max left/right shift
MAX_HEAD_SHIFT_Y = 180   # Max up/down shift

LOOK_SENSITIVITY = 1.0
HEAD_ACCEL = 0.2
MOTION_BLUR_ALPHA = 0.5  # 0 = no blur, 0.5 = balanced blend

MOVE_ACCEL = 0.1
FPS = 60

# === Load video frames and pre-convert to RGB ===
cap = cv2.VideoCapture(VIDEO_PATH)
frames = []

while True:
    ret, frame = cap.read()
    if not ret:
        break
    frame = cv2.resize(frame, (FRAME_WIDTH, FRAME_HEIGHT))
    frame = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
    frames.append(frame)

cap.release()
if not frames:
    print("No frames loaded.")
    sys.exit(1)

# === Pygame setup ===
pygame.init()
screen = pygame.display.set_mode((CROP_WIDTH, CROP_HEIGHT))
pygame.display.set_caption("Virtual Walkthrough")
clock = pygame.time.Clock()
pygame.mouse.set_visible(False)
pygame.event.set_grab(True)
pygame.mouse.set_pos([CROP_WIDTH // 2, CROP_HEIGHT // 2])

# === State ===
frame_index = 0.0
move_velocity = 0.0
target_velocity = 0.0

head_shift_x = 0.0
target_head_shift_x = 0.0
head_shift_y = 0.0
target_head_shift_y = 0.0

center_x = FRAME_WIDTH // 2
center_y = FRAME_HEIGHT // 2

blurred_frame = None  # Single blurred frame buffer

# === Main Loop ===
running = True
while running:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False
        elif event.type == pygame.KEYDOWN and event.key == pygame.K_ESCAPE:
            running = False

    # === Movement input ===
    keys = pygame.key.get_pressed()
    if keys[pygame.K_w]:
        target_velocity = 1.0
    elif keys[pygame.K_s]:
        target_velocity = -1.0
    else:
        target_velocity = 0.0

    # === Smooth movement velocity ===
    move_velocity += (target_velocity - move_velocity) * MOVE_ACCEL
    frame_index += move_velocity
    frame_index = max(0, min(len(frames) - 1, frame_index))
    int_frame_index = int(frame_index)

    # === Mouse look input ===
    mouse_x, mouse_y = pygame.mouse.get_pos()
    rel_x = mouse_x - (CROP_WIDTH // 2)
    rel_y = mouse_y - (CROP_HEIGHT // 2)

    target_head_shift_x = rel_x * LOOK_SENSITIVITY
    target_head_shift_y = rel_y * LOOK_SENSITIVITY

    target_head_shift_x = max(-MAX_HEAD_SHIFT_X, min(MAX_HEAD_SHIFT_X, target_head_shift_x))
    target_head_shift_y = max(-MAX_HEAD_SHIFT_Y, min(MAX_HEAD_SHIFT_Y, target_head_shift_y))

    head_shift_x += (target_head_shift_x - head_shift_x) * HEAD_ACCEL
    head_shift_y += (target_head_shift_y - head_shift_y) * HEAD_ACCEL

    head_shift_x = max(-MAX_HEAD_SHIFT_X, min(MAX_HEAD_SHIFT_X, head_shift_x))
    head_shift_y = max(-MAX_HEAD_SHIFT_Y, min(MAX_HEAD_SHIFT_Y, head_shift_y))

    # === Crop frame based on head look ===
    frame = frames[int_frame_index]
    crop_x = center_x - CROP_WIDTH // 2 + int(head_shift_x)
    crop_y = center_y - CROP_HEIGHT // 2 + int(head_shift_y)

    crop_x = max(0, min(FRAME_WIDTH - CROP_WIDTH, crop_x))
    crop_y = max(0, min(FRAME_HEIGHT - CROP_HEIGHT, crop_y))

    cropped = frame[crop_y:crop_y + CROP_HEIGHT, crop_x:crop_x + CROP_WIDTH]

    # === Motion blur using exponential blend ===
    if blurred_frame is None:
        blurred_frame = cropped.copy()
    else:
        cv2.addWeighted(cropped, 1.0 - MOTION_BLUR_ALPHA, blurred_frame, MOTION_BLUR_ALPHA, 0.0, dst=blurred_frame)

    # === Display ===
    surface = pygame.surfarray.make_surface(np.swapaxes(blurred_frame, 0, 1))
    screen.blit(surface, (0, 0))
    pygame.display.flip()
    clock.tick(FPS)

pygame.quit()
